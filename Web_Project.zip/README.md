# First Checkpoint
08.03.2019

* Front page
* Basic Design
* Navigation bar
* Price API
    - Coinmarketcap API

# Second Checkpoint
08.04.2019

* Other pages
    - About Ethereum
    - Historical Data
    - Contact
* Basic game in js (Easter Egg)
* Scrolling price data 
* Optimisation and bug fixes

